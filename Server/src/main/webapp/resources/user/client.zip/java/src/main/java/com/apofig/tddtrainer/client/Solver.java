package com.apofig.tddtrainer.client;

/**
 * User: sanja
 * Date: 26.01.14
 * Time: 20:27
 */
public interface Solver {

    String solve(String task);

}
